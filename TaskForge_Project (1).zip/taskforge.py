import json
import datetime

class Task:
    _id_counter = 1

    def __init__(self, title, priority, due_date, status="Pending"):
        self.id = Task._id_counter
        Task._id_counter += 1
        self.title = title
        self.priority = priority
        self.due_date = due_date
        self.status = status

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "priority": self.priority,
            "due_date": self.due_date,
            "status": self.status
        }

    @staticmethod
    def from_dict(data):
        task = Task(data["title"], data["priority"], data["due_date"], data["status"])
        task.id = data["id"]
        return task


class TaskManager:
    def __init__(self):
        self.task_list = []

    def add_task(self, title, priority, due_date):
        task = Task(title, priority, due_date)
        self.task_list.append(task)
        print(f"Task '{title}' added successfully.")

    def view_tasks(self):
        if not self.task_list:
            print("No tasks available.")
            return
        for task in self.task_list:
            print(f"[{task.id}] {task.title} | Priority: {task.priority} | Due: {task.due_date} | Status: {task.status}")

    def update_task(self, task_id, title=None, priority=None, due_date=None):
        for task in self.task_list:
            if task.id == task_id:
                if title:
                    task.title = title
                if priority:
                    task.priority = priority
                if due_date:
                    task.due_date = due_date
                print(f"Task {task_id} updated.")
                return
        print("Task not found.")

    def mark_complete(self, task_id):
        for task in self.task_list:
            if task.id == task_id:
                task.status = "Completed"
                print(f"Task {task_id} marked as completed.")
                return
        print("Task not found.")

    def delete_task(self, task_id):
        for task in self.task_list:
            if task.id == task_id:
                self.task_list.remove(task)
                print(f"Task {task_id} deleted.")
                return
        print("Task not found.")

    def save_to_file(self, filename="tasks.json"):
        with open(filename, "w") as f:
            json.dump([task.to_dict() for task in self.task_list], f, indent=4)
        print("Tasks saved to file.")

    def load_from_file(self, filename="tasks.json"):
        try:
            with open(filename, "r") as f:
                data = json.load(f)
                self.task_list = [Task.from_dict(d) for d in data]
                if self.task_list:
                    Task._id_counter = max(task.id for task in self.task_list) + 1
            print("Tasks loaded from file.")
        except FileNotFoundError:
            print("No previous task file found.")

# TaskForge – Console-Based Task Manager

## 📌 Overview
TaskForge is a Python-based console task manager application that allows users to manage their tasks from the terminal.  
It demonstrates **Object-Oriented Programming (OOP)**, **file I/O**, and **JSON persistence**.

## 🚀 Features
- Add a new task with **title, priority, due date, and status**
- View all tasks or filter by **status/due date**
- Update task details
- Mark tasks as **complete**
- Delete tasks
- Save & Load tasks from `tasks.json`

## 🏗️ Project Structure
```
TaskForge/
│── taskforge.py   # Main Python code
│── tasks.json     # Stores tasks persistently
│── README.md      # Documentation
```

## ⚡ How to Run
1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/TaskForge.git
   cd TaskForge
   ```

2. Run the program:
   ```bash
   python taskforge.py
   ```

3. Interact using the console menu.

## 📚 OOP Concepts Used
- **Encapsulation** → Task and TaskManager classes
- **Class Methods** → `to_dict()`, `from_dict()`
- **Persistence** → File I/O with JSON
- **Filtering** → by status & due date

## ✅ Example Task
```text
[1] Complete Python Project | Priority: High | Due: 2025-08-30 | Status: Pending
```
